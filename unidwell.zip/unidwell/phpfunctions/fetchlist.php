<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "unidwell";

// Create a database connection
$con = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

// Fetch listings from the database
$sql = "SELECT * FROM listings";
$result = $con->query($sql);

// Create an array to store listings
$listings = array();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // Add the row to the listings array
        $listings[] = $row;
    }
}

// Close the database connection
$con->close();

// Return listings as JSON
echo json_encode($listings);

?>
