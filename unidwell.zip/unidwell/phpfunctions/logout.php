<?php // Start or resume the session
session_start();

// Unset specific session variables
unset($_SESSION["user_id"]);
unset($_SESSION["username"]);

// Clear all session variables (optional)
$_SESSION = array();

// Destroy the session
session_destroy();

// Redirect to the login page or any other page
header("Location: ../index.php");
exit;
?>