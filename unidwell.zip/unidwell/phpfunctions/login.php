<?php
include('connection.php');
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Check user credentials
    $sql = "SELECT userid, username FROM users WHERE username = '$username' AND userpassword = md5('$password')";
    $result = $conn->query($sql);
    if (!$result) {
        die("Query Error: " . $conn->error);
    }
    if ($result->num_rows == 1) {
        // Login successful
        $row = $result->fetch_assoc();
        $_SESSION["user_id"] = $row["id"];
        $_SESSION["username"] = $row["username"];
        header ("Location: ../index.php"); // Redirect to dashboard or another page
        exit;
    } else {
        echo "Invalid username or password";
    }

    $conn->close();
}
?>