<?php
// Connect to your database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "unidwell";

// Create a database connection
$con = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

// Fetch the image data from the database for multiple records
$sql = "SELECT listingimg FROM listings";
$result = mysqli_query($con,$sql);

// Check if there are records
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $imageData = $row['listingimg'];

        // Set the content type based on the image format (e.g., image/jpeg for JPEG images)
        header('Content-Type: image/jpg'); // Adjust based on your image format

        // Output the image data
        echo $imageData;
        
        // Add HTML or other formatting as needed
        echo '<br>';
    }
} else {
    // Handle the case where no records are found
    echo "No images found.";
}

// Close the database connection
$con->close();
?>
