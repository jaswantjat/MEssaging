<?php
// Start a new session or resume the existing session
session_start();
include('connection.php');
// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect user input from the signup form
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Encrypt the password using MD5
    $encrypted_password = md5($password);

    // Prepare and execute the SQL query to insert user data
    $sql = "INSERT INTO users (username, useremail, userpassword) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $username, $email, $encrypted_password);

    if ($stmt->execute()) {
        // Redirect to a success page or login page
        header("Location: index.php");
        
        // Set a session variable to indicate successful signup
        $_SESSION['signup_success'] = true;
        exit();
    } else {
        // Set a session variable to indicate signup failure
        $_SESSION['signup_error'] = "Error: " . $stmt->error;

        // Redirect back to the signup page with an error message
        header("Location: login.html");
        exit();
    }

    // Close the database connection
    $stmt->close();
    $conn->close();
}
?>
