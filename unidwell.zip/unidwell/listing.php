<!DOCTYPE html>
<html>

<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />

  <title>UniDwell</title>

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

  <!-- fonts style -->
  <link href="https://fonts.googleapis.com/css?family=Poppins:400,700|Raleway:400,700&display=swap" rel="stylesheet">
  <!-- Custom styles for this template -->
  <link href="css/style1.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500&display=swap" rel="stylesheet">
      <!-- Stylesheet -->
      <link rel="stylesheet" href="css/listings.css" />
      <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
  <script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.js"></script>
  <script type="text/javascript" src="js/custom.js"></script>
</head>

<body class="sub_page">
  <div class="hero_area">
    <?php include('header.php'); ?>
  </div>
  <div class="container-list">
        <script>
$(document).ready(function() {
    // Fetch listings from the PHP script
    $.getJSON("phpfunctions/fetchlist.php", function(data) {
        // Loop through the fetched data and create HTML elements for each listing
        $.each(data, function(index, listing) {
            var card = `
                <div class="card-list">
                    <div class="front-list">
                    <img src="php/fetchimg.php?id=${listing.listingid}" alt="${listing.listingaddress}" />
                        <h2>${listing.listingid}</h2>
                        <h3>${listing.listingname}</h3>
                        <h6>${listing.listingrent}</h6>
                    </div>
                    <div class="back-list">
                        <button>Add To Cart</button>
                    </div>
                </div>
            `;

            // Append the card to the container
            $(".container-list").append(card);
        });
    });
});
</script>
</div>
</div>
 <?php include('footer.html'); ?> 
</body>
</html>