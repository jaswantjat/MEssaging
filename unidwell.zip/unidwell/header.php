<!DOCTYPE html>
<html>
  <?php session_start(); ?>
<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />

  <title>UniDwell</title>

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

  <!-- fonts style -->
  <link href="https://fonts.googleapis.com/css?family=Poppins:400,700|Raleway:400,700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <!-- Custom styles for this template -->
  <link href="css/header.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />
</head>

<body>
<!-- header section strats -->
<header class="header_section">
  <div class="container-fluid">
    <nav class="navbar navbar-expand-lg custom_nav-container">
      <a class="navbar-brand" href="index.html">
        <img src="" alt="Logo" /><!--Change the logo here-->
      </a>
      <div class="navbar-collapse" id="">
        <ul class="navbar-nav justify-content-between ">
          <div class="User_option">
            <li class="">
              <?php if (isset($_SESSION["username"])) {
                echo "Welcome, " . $_SESSION["username"];?>
                 <a class="mr-4" href="phpfunctions/logout.php">
                        Logout
                      </a> <?php }
                else { ?>
              <a class="mr-4" href="login.html">
                Login
              </a>
              <a class="mr-4" href="login.html">
                Sign up
              </a>
              <a class="" href="listing.php">
                Listings
              </a><?php } ?>
            </li>
          </div>
        </ul>

        <div class="custom_menu-btn">
          <button onclick="openNav()">
            <span class="s-1"></span>
            <span class="s-2"></span>
            <span class="s-3"></span>
          </button>
        </div>
        <div id="myNav" class="overlay">
          <div class="overlay-content">
            <a href="index.php">HOME</a>
            <a href="about.php">ABOUT</a>
            <a href="listings.php">LISTINGS</a>
            <a href="price.php">SERVICES</a>
            <a href="contact.php">CONTACT US</a>
          </div>
        </div>
      </div>
    </nav>
  </div>
</header>
<!-- end header section -->
                </body>
                </html>