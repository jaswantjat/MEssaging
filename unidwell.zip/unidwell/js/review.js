$(document).ready(function() {
    $('.owl-carousel').owlCarousel({
      loop: true,
      items: 1,          // Show one review per slide
      autoplay: true,    // Enable auto-play
      autoplayTimeout: 2000, // Set time between slides in milliseconds (e.g., 5000ms = 5 seconds)
      autoplayHoverPause: true, // Pause autoplay when the mouse hovers over the carousel
      nav: false,
      dots: true
    });
  });
  