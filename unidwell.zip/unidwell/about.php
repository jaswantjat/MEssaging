<!DOCTYPE html>
<html>

<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />

  <title>About Us</title>


  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

  <!-- fonts style -->
  <link href="https://fonts.googleapis.com/css?family=Poppins:400,700|Raleway:400,700&display=swap" rel="stylesheet">
  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />
</head>

<body class="sub_page">
  <div class="hero_area">
  <?php include('header.php'); ?>

  <!-- about section -->

  <section class="about_section layout_padding-bottom">
    <div class="square-box">
      <img src="images/client.jpg" alt="">
    </div>
    <div class="container-about">
      <div class="row">
        <div class="col-md-6">
          <div class="img-box">
            <img src="images/contact.jpg" alt="">
          </div>
        </div>
        <div class="col-md-6">
          <div class="detail-box">
            <div class="heading_container">
              <h2>
                About Our Apartments <!--changed-->
              </h2>
            </div>
            <p>
              Welcome to Unidwell!!!   <!--changed-->

              At Unidwell, we're dedicated to providing you with the best house rental experience possible. Whether
              you're searching for your dream home, a temporary residence, or an rental flats, we're here to make
              the process seamless and enjoyable.
            </p>

            <h3>Our Mission   <!--changed-->

            </h3>
            <p> Our mission is to connect individuals and Students with the perfect houses for their needs. We
              understand that a house is more than just a place to live—it's where memories are created and stories
              unfold. That's why we're committed to helping you find a house that you can truly call home.
            </p>

          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- end about section -->
  <?php include('footer.html'); ?>

  <script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.js"></script>
  <script type="text/javascript" src="js/custom.js"></script>

</body>
</html>